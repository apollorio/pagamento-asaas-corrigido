/**
 * Plugin JS file
 *
 * This file hasn't any functionality. If it's not necessary, will be deleted.
 *
 * @package WooAsaas
 */

import './components/mask-input';
import './components/copy-to-clipboard';
import './components/one-click-buy-option';
