import './components/anticipation-configuration';
import './components/webhooks-configuration';
import './components/split-object-setting-table';
import './components/split-wallet-configuration';
