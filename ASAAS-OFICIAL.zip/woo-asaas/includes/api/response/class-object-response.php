<?php
/**
 * API response handler class
 *
 * @package WooAsaas
 */

namespace WC_Asaas\Api\Response;

/**
 * API response handler class
 */
class Object_Response extends Response {

}
