<?php

namespace WC_Asaas\Common\Repository;

use Exception;

class Register_Not_Found_Exception extends Exception {
}
