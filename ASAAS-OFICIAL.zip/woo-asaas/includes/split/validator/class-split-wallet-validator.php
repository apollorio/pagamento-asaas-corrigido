<?php

namespace WC_Asaas\Split\Validator;

use WC_Asaas\Common\Validator\Validator;

abstract class Split_Wallet_Validator extends Validator {

	protected $exception_message = 'Invalid wallet.';
}
